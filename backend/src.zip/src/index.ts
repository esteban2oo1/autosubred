import express from 'express'
import cors from 'cors'
import sshRoutes from './routes/ssh'
import dhcpRoutes from './routes/dhcp'
import subnetRoutes from './routes/subnet'

const app = express()
const port = process.env.PORT || 3001

// Middleware
app.use(cors())
app.use(express.json())

// Rutas
app.use('/api/ssh', sshRoutes)
app.use('/api/dhcp', dhcpRoutes)
app.use('/api/subnets', subnetRoutes)

// Manejo de errores
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error(err.stack)
  res.status(500).json({
    success: false,
    message: 'Error interno del servidor'
  })
})

app.listen(port, () => {
  console.log(`Servidor backend ejecutándose en el puerto ${port}`)
}) 