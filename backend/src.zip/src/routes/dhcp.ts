import express from 'express'
import { Client } from 'ssh2'

const router = express.Router()

router.post('/configure', async (req, res) => {
  const { config, connectionId } = req.body

  if (!config || !connectionId) {
    return res.status(400).json({
      success: false,
      message: 'Faltan parámetros de configuración'
    })
  }

  // Aquí implementaríamos la lógica para aplicar la configuración DHCP
  // usando la conexión SSH activa identificada por connectionId

  res.json({
    success: true,
    message: 'Configuración DHCP aplicada correctamente'
  })
})

export default router 